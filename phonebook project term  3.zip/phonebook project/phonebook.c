#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "phonebook.h"

int main()
{
    system("color f0");
    load();
    return 0;
}
